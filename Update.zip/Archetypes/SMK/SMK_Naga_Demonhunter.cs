﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBotAPI.Plugins.API
{

    public class SMK_NagaDemonhunter : Archetype
    {
        public string ArchetypeName()
        {
            return "SMK_Naga_Demonhunter";
        }

        public List<Card.Cards> ArchetypeCardSet()
        {
            return new List<Card.Cards>()
            {
                Cards.Battlefiend,
                Cards.BeamingSidekick,
                Cards.DreadprisonGlaive,
                Cards.IrondeepTrogg,
                Cards.MultiStrike,
                Cards.ViciousSlitherspear,
                Cards.BattlewornVanguard,
                Cards.ChaosStrike,
                Cards.SpectralSight,
                Cards.WaywardSage,
                Cards.LadyStheno,
                Cards.Predation,
                Cards.Pufferfist,
                Cards.DrekThar,
                Cards.BoneGlaive,
                Cards.KurtrusDemonRender,
                Cards.FuryRank1,
                Cards.MurkwaterScribe,
                Cards.NeedforGreed,
            };
        }
    }
}