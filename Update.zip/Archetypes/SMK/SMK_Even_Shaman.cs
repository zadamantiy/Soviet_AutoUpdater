﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBotAPI.Plugins.API
{

    public class TokenShamanArchetype : Archetype
    {
        public string ArchetypeName()
        {
            return "Token Shaman";
        }

        public List<Card.Cards> ArchetypeCardSet()
        {
            return new List<Card.Cards>()
            {
                Cards.Evolve,
                Cards.Doppelgangster,
                Cards.BloodsailCorsair,
                Cards.FireFly,
                Cards.PatchesthePirate,
                Cards.UnstableEvolution,
                Cards.FlametongueTotem,
                Cards.JadeSpirit,
                Cards.ThrallDeathseer,
                Cards.ThingfromBelow,
                Cards.SouthseaDeckhand,
                Cards.BloodmageThalnos,
                Cards.Devolve,
                Cards.JadeClaws,
                Cards.MaelstromPortal,
                Cards.PrimalfinTotem,
                Cards.LightningStorm,
                Cards.ManaTideTotem,
                Cards.StonehillDefender,
                Cards.Hex,
                Cards.JadeLightning,
                Cards.SaroniteChainGang,
                Cards.Bloodlust,
                Cards.Volcano,
                Cards.AyaBlackpaw,
                Cards.GrumbleWorldshaker,
                Cards.NerubianProphet,
                Cards.CorridorCreeper,
                Cards.JadeChieftain,
            };
        }
    }
}