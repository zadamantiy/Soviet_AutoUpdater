﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBotAPI.Plugins.API
{

    public class SMK_TokenDruid : Archetype
    {
        public string ArchetypeName()
        {
            return "SMK_Token_Druid";
        }

        public List<Card.Cards> ArchetypeCardSet()
        {
            return new List<Card.Cards>()
            {
                Cards.LesserJasperSpellstone,
                Cards.PoweroftheWild,
                Cards.WildGrowth,
                Cards.SavageRoar,
                Cards.BranchingPaths,
                Cards.SouloftheForest,
                Cards.Swipe,
                Cards.WisperingWoods,
                Cards.ArcaneTyrant,
                Cards.GigglingInventor,
                Cards.Nourish,
                Cards.SpreadingPlague,
                Cards.MalfurionthePestilent,
                Cards.UltimateInfestation,

                Cards.FlobbidinousFloop,
                Cards.OakenSummons,
                Cards.SaroniteChainGang,
                Cards.StrongshellScavenger,
                Cards.VioletTeacher
            };
        }
    }
}