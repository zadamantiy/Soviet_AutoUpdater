﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBotAPI.Plugins.API
{

    public class SMK_OddPaladin : Archetype
    {
        public string ArchetypeName()
        {
            return "SMK_Odd_Paladin";
        }

        public List<Card.Cards> ArchetypeCardSet()
        {
            return new List<Card.Cards>()
            {
                Cards.AcherusVeteran,
                Cards.ArgentSquire,
                Cards.LostintheJungle,
                Cards.RighteousProtector,
                Cards.DivineFavor,
                Cards.UnidentifiedMaul,
                Cards.Fungalmancer,
                Cards.LevelUp,
                Cards.Vinecleaver,
                Cards.BakutheMooneater,
                Cards.BlessingofMight,
                Cards.DireMole,
                Cards.FireFly,
                Cards.GlacialShard,
                Cards.LightsJustice,
                Cards.IronbeakOwl,
                Cards.RaidLeader,
                Cards.StonehillDefender,
                Cards.CorridorCreeper,
                Cards.StormwindChampion,
                Cards.NightmareAmalgam,

                //The Boomsday Project
                Card.Cards.BOT_912, //Kangor's Endless Army
                Card.Cards.BOT_906, //Glow-Tron
                Card.Cards.BOT_548, //Zilliax
                Card.Cards.BOT_563, //Wargear
                Card.Cards.BOT_270, //Giggling Inventor
                Card.Cards.BOT_021, //Bronze Gatekeeper
                Card.Cards.BOT_537, //Mechano-Egg
            };
        }
    }
}