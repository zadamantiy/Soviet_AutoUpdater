﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBotAPI.Plugins.API
{
    public class SMKQuestWarriorArchetype : Archetype
    {
        public string ArchetypeName()
        {
            return "SMK_Quest_Warrior";
        }

        public List<Card.Cards> ArchetypeCardSet()
        {
            return new List<Card.Cards>()
            {
                Cards.Core.BloodsailDeckhand,
                Cards.RaidtheDocks,
                Cards.ShiverTheirTimbers,
                Cards.WhetstoneHatchet,
                Cards.AmalgamoftheDeep,
                Cards.BloodsailRaider,
                Cards.Core.FogsailFreebooter,
                Cards.HarborScamp,
                Cards.Obsidiansmith,
                Cards.TuskarrrrTrawler,
                Cards.CargoGuard,
                Cards.DefiasCannoneer,
                Cards.Pufferfist,
                Cards.SouthseaCaptain,
                Cards.StormwindFreebooter,
                Cards.MrSmite,
                Cards.NellietheGreatThresher
            };
        }
    }
}