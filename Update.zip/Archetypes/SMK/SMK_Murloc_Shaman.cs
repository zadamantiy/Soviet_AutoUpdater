﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBotAPI.Plugins.API
{

    public class SMK_MurlocShaman : Archetype
    {
        public string ArchetypeName()
        {
            return "SMK_Murloc_Shaman";
        }

        public List<Card.Cards> ArchetypeCardSet()
        {
            return new List<Card.Cards>()
            {
                Cards.GrimscaleOracle,
                Cards.MurlocTidecaller,
                Cards.SludgeSlurper,
                Cards.Toxfin,
                Cards.GhostLightAngler,
                Cards.MurlocTidehunter,
                Cards.SouloftheMurloc,
                Cards.UnderbellyAngler,
                Cards.ColdlightSeer,
                Cards.MurlocWarleader,
                Cards.MurlocTastyfin,
                Cards.Scargil,
                Cards.Bloodlust,
                Cards.MurlocRaider,
                Cards.BluegillWarrior,
                Cards.HenchClanHogsteed,
                Cards.Likkim,
                Cards.NightmareAmalgam,
                Cards.HagathatheWitch,
            };
        }
    }
}