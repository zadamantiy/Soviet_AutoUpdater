﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBot.Mulligan
{
    
    //Console Mulligan Tester
    /*
    class Program
    {
        /*
        static void Main(string[] args)
        {
            Universal z = new Universal();
            List<Card.Cards> CardList = new List<Card.Cards>
            {
                //Start Hand
                Cards.CorridorCreeper,
                Cards.FireFly,
                Cards.FireFly,
                //Cards.CorridorCreeper
            };
    
            List<Card.Cards> Keeped = z.HandleMulligan(CardList, Card.CClass.DRUID, Card.CClass.DRUID);
            foreach (var card in Keeped)
            {
                Console.WriteLine(CardTemplate.LoadFromId(card).Name);
            }
            Console.ReadLine();
        }
    }
    */
    

    [Serializable]
    public class Universal : MulliganProfile
    {
        private const bool BlnDebugMode = true;

        private const string Version = "0.4β";
        private const string SBuild = "0020";
        private const string SName = "Universal";

        private const string SDivider = "======================================================";

        private string _log = "";

        private List<Card.Cards> _choices;
        private readonly List<Card.Cards> _keep = new List<Card.Cards>();
        private List<Card.Cards> _myDeck;
        private Card.CClass _opponentClass;

        private readonly IniManager _iniTierList =
            new IniManager(Directory.GetCurrentDirectory() + @"\MulliganProfiles\Files\SovietArena_TierList.ini");

        private string MulliganInfo()
        {
            string sTierListVersion = _iniTierList.GetString("info", "version", "unknown");
            string sTierListName = _iniTierList.GetString("info", "name", "Basic");

            if (sTierListName == "Basic")
            {
                return null;
                //return _keep;
            }

            string info = SDivider + "\r\nSoviet " + SName + ":" + sTierListName + "\r\n" + SDivider;

            info += "\r\nCore version: Build" + SBuild;
            info += "\r\nTierList version: Build" + sTierListVersion;
            info += "\r\n" + SDivider;

            return info;
        }

        private Dictionary<string, int> _comboDic;

        //KEEP_CARD
        private bool Keep(string reason, params Card.Cards[] cards)
        {
            var count = true;
            string str = "> Keep: ";
            foreach (var card in cards)
            {
                if (!_choices.Contains(card)) continue;

                var cardTemp = CardTemplate.LoadFromId(card);
                str += cardTemp.Name + ",";
                _choices.Remove(card);
                _keep.Add(card);
                //cardCost[cardTemp.Cost]--;
                count = false;
            }
            if (count) return false;
            str = str.Remove(str.Length - 1);
            if (reason != null)
                str += " because " + reason;
            AddLog(str);

            return true;
        }

        //REMOVE_CARD
        private bool RemoveCard(params Card.Cards[] cards)
        {
            var count = true;
            string str = "> Remove: ";

            foreach (var card in cards)
            {
                if (_keep.Contains(card))
                {
                    //var cardTemp = CardTemplate.LoadFromId(card);
                    str += CardTemplate.LoadFromId(card).Name + ",";
                    _keep.Remove(card);
                    _choices.Add(card);
                    //cardCost[cardTemp.Cost - 1]--;
                    count = false;
                }
            }

            if (count) return false;
            str = str.Remove(str.Length - 1);
            AddLog(str);

            return true;
        }

        //ADD_LOG
        private void AddLog(string s)
        {
            _log += "\r\n" + s;
        }

        //PRINT_LOG
        private void PrintLog()
        {
            Bot.Log(_log);

            string sDir = Directory.GetCurrentDirectory() + @"\Logs\Soviet\Universal\";

            if (!Directory.Exists(sDir))
                Directory.CreateDirectory(sDir);

            File.AppendAllText(Directory.GetCurrentDirectory() + @"\Logs\Soviet\Universal\Universal.log", _log);

            _log = "\r\n---Soviet " + SName + " v" + Version + "---";
        }

        private void LogDebug()
        {
            AddLog("[SU-DЕBUG] Dir  = " + Directory.GetCurrentDirectory());
            AddLog("[SU-DЕBUG] Mode = " + Bot.CurrentMode());
            AddLog("[SU-DЕBUG] Time = " + DateTime.Now);
            AddLog(SDivider);
        }

        //MAIN

        //TODO: 
        //Fields Has_0Drop, Has_1Drop

        //DECK INFO
        //Fields Deck_Has_No_2Drop, Deck_Has_No_3Drop
        //Field no_rptd_cards

        //Race fields: Beast, murloc etc
        public List<Card.Cards> HandleMulligan(List<Card.Cards> choices, Card.CClass opponentClass,
            Card.CClass ownClass)
        {
            try
            {
                _myDeck = Bot.CurrentDeck().Cards.Select(card => (Card.Cards) Enum.Parse(typeof(Card.Cards), card))
                    .ToList();
            }
            catch
            {
                _myDeck = new List<Card.Cards> {Cards.AzureDrake, Cards.SirFinleyMrrgglton};
            }

            string tempString = MulliganInfo();
            if (tempString != null)
            {
                AddLog(tempString);
            }
            else
            {
                AddLog(SDivider);
                AddLog("ERROR!!!");
                AddLog("MULLIGAN IS INSTALLED WRONG");
                AddLog("PLEASE, FOLLOW THE INSTRUCTIONS AT THE TOPIC:");
                AddLog("https://sb-forum.com/index.php?/topic/8667-SovietArena/");
                AddLog("Doesn't matter if this is arena mulligan ot not.");
                AddLog(SDivider);
                LogDebug();
                PrintLog();
                return _keep;
            }

            //Mode Preferences

            #region Mode Preferences
            //ARENA
            if (Bot.CurrentMode() == Bot.Mode.ArenaAuto || Bot.CurrentMode() == Bot.Mode.Arena)
            {
                _comboDic = new Dictionary<string, int>()
                {
                    //coin
                    {"12200", 35},
                    {"12110", 35},
                    {"12100", 20},
                    {"11111", 40},
                    {"11110", 30},
                    {"11102", 35},
                    {"11101", 25},
                    {"11100", 20},
                    {"11021", 35},
                    {"11020", 25},
                    {"11010", 15},
                    {"10211", 35},
                    {"10210", 25},
                    {"10110", 10},
                    {"10010", 0},
                    {"10020", 0},
                    {"10030", -45},
                    {"10040", -60},
                    //no coin
                    {"01110", 30},
                    {"01100", 20},
                    {"01010", 15},
                    {"02010", 0},
                    {"00110", 0},
                    {"00030", -45},
                    {"00020", -30},
                    {"00010", 0},
                };
            }
            //Another
            else
            {
                _comboDic = new Dictionary<string, int>()
                {
                    //coin
                    {"12200", 30},
                    {"12100", 0},
                    {"11111", 40},
                    {"11110", 30},
                    {"11102", 35},
                    {"11101", 25},
                    {"11100", 20},
                    {"11021", 35},
                    {"11020", 25},
                    {"11010", 15},
                    {"10211", 35},
                    {"10210", 25},
                    {"10030", -45},
                    {"10040", -60},
                    //no coin
                    {"01110", 30},
                    {"01100", 20},
                    {"01010", 15},
                    {"02100", -10},
                };
            }

            #endregion

            //Define our globals
            _choices = choices;
            _opponentClass = opponentClass;

            AddLog("Match info: ");
            AddLog("Class: " + ownClass);
            AddLog("Opponent: " + _opponentClass);

            //Defines the coin.
            bool coin = _choices.Count >= 4;
            if (coin)
                Keep(null, Card.Cards.GAME_005);

            AddLog("Coin: " + coin);
            AddLog(SDivider);

            AddLog("Offered:");
            foreach (var card in _choices)
            {
                var cardTmpText = CardTemplate.LoadFromId(card).Name + " (" + card + ")";

                AddLog("> " + cardTmpText);
            }
            AddLog(SDivider);

            //LOAD ID 

            int[] iCardPts = new int[_choices.Count];
            int[,] iCardInteractionPts = new int[_choices.Count, _choices.Count];


            for (var i = 0; i < choices.Count; i++)
            {
                var card = choices[i];

                int.TryParse(_iniTierList.GetString(string.Format("card_{0}", card), "class_ANY", "-50"),
                    out iCardPts[i]);

                //AddLog("> " + String.Format("card_{0}", card));

                int temp;

                int.TryParse(
                    _iniTierList.GetString(string.Format("card_{0}", card), string.Format("class_{0}", ownClass),
                        "-1917"), out temp);

                iCardPts[i] = (temp == -1917) ? iCardPts[i] : temp;

                int.TryParse(
                    _iniTierList.GetString(string.Format("card_{0}", card),
                        string.Format("opp_{0}", _opponentClass), "0"), out temp);
                iCardPts[i] += temp;

                if (coin)
                {
                    int.TryParse(_iniTierList.GetString(string.Format("card_{0}", card), "coin", "0"), out temp);
                    iCardPts[i] += temp;
                }

                for (var j = 0; j < choices.Count; j++)
                {
                    if (j == i) continue;
                    var card2 = choices[j];
                    int.TryParse(
                        _iniTierList.GetString(string.Format("card_{0}", card), string.Format("pCard_{0}", card2),
                            "0"), out iCardInteractionPts[i, j]);
                }
            }

            int[,,,] combinationPts = new int[2, 2, 2, 2];
            double[,,,] combinationPtsPerCrd = new double[2, 2, 2, 2];
            bool[,,,] combinationCmb = new bool[2, 2, 2, 2];
            int[,,,,] combinationInt = new int[2, 2, 2, 2, 4];
            int[,,,,] combinationCst = new int[2, 2, 2, 2, 6];

            string bestComboVal = "0000";
            int bestComboPts = 0;
            double bestComboPtsPerCard = 0;
            int bestCardCount = 0;

            for (var i = 0; i < 2; i++)
            for (var j = 0; j < 2; j++)
            for (var k = 0; k < 2; k++)
            for (var l = 0; (l < 2 && coin || l < 1 && !coin); l++)
            {
                for (var it = 0; it < choices.Count; it++)
                {
                    //var card = choices[it];

                    if ((it == 0 && i == 0) ||
                        (it == 1 && j == 0) ||
                        (it == 2 && k == 0) ||
                        (it == 3 && l == 0)) continue;

                    combinationPts[i, j, k, l] += iCardPts[it];
                    combinationInt[i, j, k, l, it] += iCardPts[it];

                    for (var jt = 0; jt < choices.Count; jt++)
                    {
                        if ((jt == it) ||
                            (jt == 0 && i == 0) ||
                            (jt == 1 && j == 0) ||
                            (jt == 2 && k == 0) ||
                            (jt == 3 && l == 0)) continue;

                        //var card2 = choices[jt];

                        combinationInt[i, j, k, l, jt] += iCardInteractionPts[it, jt];
                        combinationPts[i, j, k, l] += iCardInteractionPts[it, jt];
                    }
                }

                for (var it = 0; it < choices.Count; it++)
                {
                    var card = choices[it];
                    var cardTmp = CardTemplate.LoadFromId(card);

                    if ((it == 0 && i == 0) ||
                        (it == 1 && j == 0) ||
                        (it == 2 && k == 0) ||
                        (it == 3 && l == 0)) continue;

                    int tmp = cardTmp.Cost;

                    /* FIXME: dirty hack */
                    if (card == Cards.NerubianProphet) tmp = 3;
                    if (card == Cards.CorridorCreeper) tmp = 3;

                    combinationCst[i, j, k, l, Math.Min(5, tmp)]++;
                }

                //int ptsNcPerCard = combinationPts[i, j, k, l] / (i+j+k+l+1);

                //TODO: MB BETTER TO REWORK COMBO FORMAT
                var curCombo = string.Format
                (
                    "{0}{1}{2}{3}{4}",
                    coin ? 1 : 0,
                    combinationCst[i, j, k, l, 1],
                    combinationCst[i, j, k, l, 2],
                    combinationCst[i, j, k, l, 3],
                    combinationCst[i, j, k, l, 4]
                );

                if (_comboDic.ContainsKey(curCombo) && combinationCst[i, j, k, l, 5] == 0)
                {
                    combinationPts[i, j, k, l] += _comboDic[curCombo];
                    combinationCmb[i, j, k, l] = true;
                }

                //Extra cards value reduce
                if (!combinationCmb[i, j, k, l])
                {
                    combinationPts[i, j, k, l] -= combinationCst[i, j, k, l, 5] * 150;
                    combinationPts[i, j, k, l] -= combinationCst[i, j, k, l, 4] * 100;
                    combinationPts[i, j, k, l] -= combinationCst[i, j, k, l, 3] * 75;
                    if (!coin && combinationCst[i, j, k, l, 2] > 1)
                        combinationPts[i, j, k, l] -= (combinationCst[i, j, k, l, 2] - 1) * 55;
                    else if (coin && combinationCst[i, j, k, l, 2] > 2)
                    {
                        combinationPts[i, j, k, l] -= (combinationCst[i, j, k, l, 2] - 2) * 55;
                    }
                    if (!coin && combinationCst[i, j, k, l, 1] > 2)
                        combinationPts[i, j, k, l] -= (combinationCst[i, j, k, l, 1] - 2) * 30;
                    else if (coin && combinationCst[i, j, k, l, 1] > 2)
                    {
                        combinationPts[i, j, k, l] -= (combinationCst[i, j, k, l, 2] - 1) * 20;
                    }
                }
                if (combinationCst[i, j, k, l, 0] > 1)
                {
                    combinationPts[i, j, k, l] -= (combinationCst[i, j, k, l, 0] - 1) * 20;
                }

                /* FIXME: dirty hack */
                if ((i == 1 && choices[0] == Cards.CorridorCreeper) ||
                    (j == 1 && choices[1] == Cards.CorridorCreeper) ||
                    (k == 1 && choices[2] == Cards.CorridorCreeper) ||
                    (l == 1 && choices[3] == Cards.CorridorCreeper))
                {
                    for (var it = 0; it < choices.Count; it++)
                    {
                        if ((it == 0 && i == 0) ||
                            (it == 1 && j == 0) ||
                            (it == 2 && k == 0) ||
                            (it == 3 && l == 0)) continue;

                        combinationPts[i, j, k, l] += GetTokenCount(choices[it]) * 12;
                    }
                }

                var cardCount = i + j + k + l;
                if (i + j + k + l != 0)
                    combinationPtsPerCrd[i, j, k, l] = (double) combinationPts[i, j, k, l] / cardCount;

                if (BlnDebugMode)
                {
                    AddLog(string.Format("Combination: {0}{1}{2}{3} -- Points: {4,5} -- Pts/Card: {5:###.##}", i, j,
                        k, l, combinationPts[i, j, k, l], combinationPtsPerCrd[i, j, k, l]));
                }

                if (combinationPts[i, j, k, l] >= cardCount * 100 &&
                    (bestComboPts < combinationPts[i, j, k, l] || bestComboPts == combinationPts[i, j, k, l] &&
                        cardCount > bestCardCount))
                {
                    bestCardCount = cardCount;
                    bestComboPts = combinationPts[i, j, k, l];
                    bestComboPtsPerCard = combinationPtsPerCrd[i, j, k, l];
                    bestComboVal = string.Format("{0}{1}{2}{3}", i, j, k, l);
                }
            }

            AddLog(string.Format("Best Combination: {0} -- Points: {1} -- Pts/Card: {2:###.##}", bestComboVal,
                bestComboPts, bestComboPtsPerCard));
            AddLog(SDivider);

            AddLog("Finally keeping:");

            List<Card.Cards> lccKeeping = new List<Card.Cards>();
            for (var i = _choices.Count - 1; i >= 0; i--)
            {
                if (bestComboVal[i] == '1')
                    lccKeeping.Add(_choices[i]);
            }

            foreach (var card in lccKeeping)
            {
                Keep(null, card);
            }

            if (lccKeeping.Count == 0) AddLog("Nothing");

            AddLog(SDivider);

            if (BlnDebugMode)
                LogDebug();

            //Ending
            PrintLog();

            return _keep;
        }

        private int GetTokenCount(Card.Cards card)
        {
            CardTemplate cardTmp = CardTemplate.LoadFromId(card);
            if (_tokens.ContainsKey(card))
                return _tokens[card];

            return cardTmp.Type == Card.CType.MINION ? 1 : 0;
        }

        private readonly Dictionary<Card.Cards, int> _tokens = new Dictionary<Card.Cards, int>()
        {
            //Summon
            //Druid
            {Cards.MireKeeper, 2},
            //Hunter
            {Cards.Alleycat, 2},
            {Cards.KindlyGrandmother, 2},
            {Cards.SnakeTrap, 3},
            {Cards.VenomstrikeTrap, 1},
            {Cards.AnimalCompanion, 1},
            {Cards.RatPack, 2},
            {Cards.UnleashtheHounds, 2}, //?
            {Cards.FlankingStrike, 1},
            {Cards.InfestedWolf, 2},
            //Mage
            {Cards.MirrorImage, 2},
            {Cards.MirrorEntity, 1},
            //Paladin
            {Cards.LostintheJungle, 2},
            {Cards.NobleSacrifice, 1},
            {Cards.LesserPearlSpellstone, 1},
            //Priest
            {Cards.MirageCaller, 2},
            {Cards.EternalServitude, 1},
            //Rogue
            {Cards.DefiasRingleader, 2}, //coin
            {Cards.JadeShuriken, 2}, //coin
            {Cards.JadeSwarmer, 2},
            //Shaman
            {Cards.JadeClaws, 1},
            {Cards.KoboldHermit, 2},
            {Cards.MaelstromPortal, 1},
            {Cards.FeralSpirit, 2}, //hmm 
            {Cards.PrimalfinTotem, 2},
            {Cards.CallintheFinishers, 4},
            //Warlock
            {Cards.PossessedVillager, 2},
            {Cards.CorneredSentry, 4}, //3 for opponent, hmm
            //Neutral
            {Cards.BilefinTidehunter, 2},
            {Cards.MurlocTidehunter, 2},
            {Cards.Eggnapper, 3},
            {Cards.HarvestGolem, 2},
            {Cards.ImpMaster, 2},
            {Cards.Moroes, 2},
            {Cards.PantrySpider, 2},
            {Cards.RazorfenHunter, 2},
            {Cards.SewerCrawler, 2},
            {Cards.ShriekingShroom, 2},
            {Cards.Arcanosmith, 2},
            {Cards.Barnes, 2},
            {Cards.CursedDisciple, 2},
            {Cards.DragonlingMechanic, 2},
            {Cards.GrimNecromancer, 3},
            {Cards.InfestedTauren, 2},
            {Cards.JadeSpirit, 2},
            {Cards.MeatWagon, 2},
            {Cards.RattlingRascal, 2},
            {Cards.SaroniteChainGang, 2},

            //ADD mechanic
            //Neutral
            {Cards.FireFly, 2},
            {Cards.IgneousElemental, 3},
            //Hunter
            {Cards.JeweledMacaw, 2},
            //Mage
            {Cards.FlameGeyser, 1},
            //Paladin
            {Cards.DrygulchJailor, 4},
        };
    }

    //TODO: Card class
    //public class 
    //{
    //
    //}

    public class IniManager
    {
        private const int CSize = 1024;

        public IniManager(string path)
        {
            Path = path;
        }

        //For empty
        public IniManager()
            : this("")
        {
        }

        public string Path { get; set; }

        public string GetString(string section, string key, string Default = null)
        {
            StringBuilder buffer = new StringBuilder(CSize);
            GetString(section, key, Default, buffer, CSize, Path);
            return buffer.ToString();
        }

        public void WriteString(string section, string key, string sValue)
        {
            WriteString(section, key, sValue, Path);
        }

        [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileString")]
        private static extern int GetString(string section, string key, string def, StringBuilder bufer, int size,
            string path);

        [DllImport("kernel32.dll", EntryPoint = "WritePrivateProfileString")]
        private static extern int WriteString(string section, string key, string str, string path);
    }
}